function PlotCompetLearn(W,V,P)

% PlotCompetLearn(W,V,P)  --  graphics for competitive learning demo.
%
%    W = weight matrix NUNITS x NINPUTS
%    V = winner matrix NUNITS x NPATS
%    P = patterns: NPATS x NINPUTS

clf, whitebg(gcf,[0 0 0])
set(gca,'NextPlot','add');

[NUNITS,NINPUTS] = size(W);
NPATS = size(P,1);

colors = get(gca,'ColorOrder');
white = [1 1 1];

axis('square');
axis([-2 2 -2 2]);
title('Competitive Learning');

%   Plot a circle
x=0:pi/50:2*pi;
plot(cos(x),sin(x),'-','Color',white);

%   Plot the weight vectors, each in a different color.
for i=1:NUNITS
  plot([0 W(i,1)],[0 W(i,2)],'-','Color',colors(i,:));
  end


%   Plot the inputs
plot(P(:,1),P(:,2),'+','Color',white);

%   Plot the normalized inputs, each in the color of
%   the weight vector that captures it.
normpats = normv(P);
for i = 1:NPATS
  [m,wincolor] = max(V(:,i));
  plot(normpats(i,1),normpats(i,2),'o','Color',colors(wincolor,:));
  end
