function compet2(NUNITS)
% Competitive learning demo.
%
%   compet2          -- run with 5 units
%   compet2(NUNITS)  -- run with NUNITS units

load CompetPat2.dat

Patterns = CompetPat2;

NPATS   = size(Patterns,1);
NINPUTS = size(Patterns,2);

NormPats = normv(Patterns);

if nargin == 0, NUNITS = 5; end
LearnRate = 0.25;

InitWeights = normv(rand(NUNITS,NINPUTS)-0.5);
Weights = InitWeights;

OldWeights = Weights * 0;

for i=1:20

 NetIn = (Weights*NormPats');
 maxacts = max(NetIn);
 maxmat = ones(NUNITS,1)*maxacts;
 winners = (NetIn == maxmat);

 PlotCompetLearn(Weights,winners,Patterns);

 dW = LearnRate * (winners * NormPats);

 OldWeights = Weights;
 Weights = normv(Weights + dW);

 dotprods = sum((OldWeights.*Weights)');
 fprintf('Epoch %.0f, dotprods:',i);
 disp(dotprods);

 if all(dotprods > .999)
    break
  else
    pause(1);
  end

 end
