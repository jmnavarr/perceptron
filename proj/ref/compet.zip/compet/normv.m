function WN = normv(W)
% normv(W) - return normalized vectors
%
%	W is a matrix whose rows are vectors

WN = W./(sqrt(sum((W.*W)')')*ones(1,size(W,2)));
