% EMPRINT -- display results of EM learning

  fprintf('\n\nBump   Mu_x ,    Mu_y        Sigma       Weight\n')

  for j = 1:Nbumps
    fprintf('%2d: %8.3f, %8.3f    %9.5f     %7.5f\n', ...
	j, Mu_jd(j,1),Mu_jd(j,2),sqrt(SigmaSq_j1(j)),P_j1(j))
  end


fprintf('Log likelihood E = %g\n',sum(-log(sum(P_nj .* repmat(P_j1',Npats,1),2))))
