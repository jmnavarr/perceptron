% S = EMSIGMASQ(J,MU_JD)

function S = emsigmasq(J,Mu_jd)

  Nbumps = size(Mu_jd,1);
  coords = ones(Nbumps,1) * Mu_jd(J,:);

  distvals = sum((Mu_jd-coords)'.^2);
  distvals(J) = Inf;
  S = min(distvals);
