% RANDG2(N) returns an N-by-2 matrix of points drawn from a 2D gaussian
%           distribution with mean 0 and variance 1.

function z = randg2(n)

  r = randn(n,1);
  phi = rand(n,1)*2*pi;

  x = r .* cos(phi);
  y = r .* sin(phi);

  z = [x,y];
