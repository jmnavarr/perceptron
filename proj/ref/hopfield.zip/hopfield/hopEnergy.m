function hopEnergy( finalFlag )

% hopEnergy.m
%
%  Compute the energy of the current Hopfield network state.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global hTab;
global boltzmannPopup;
global unitsPopup;
global W;
global energyText;

sTab = cell2mat( get( hTab, 'UserData' ) );

if get(boltzmannPopup,'Value') == 3

	% for mean field approximation networks, the state
	% stored per unit is the actual value.

else

	% for stochastic networks, the state stored is binary
	% 0/1, and must be converted to -1/+1 if using that
	% type of unit

	if get(unitsPopup,'Value') == 2
		% 0/+1 units
	else
		% -1/+1 units
		sTab = 2 * sTab - 1;
	end

end

E = -0.5 * sTab' * W * sTab;

if finalFlag == 0

	% in purple
	set(energyText,'String',sprintf('Energy  =  %g',E));
	set(energyText,'BackgroundColor',[.9 .5 .9]);

else

	% in green
	set(energyText,'String',sprintf('Final Energy  =  %g',E));
	set(energyText,'BackgroundColor',[0.2 0.8 0.2]);
end

drawnow

