% hopRandNet_callback.m
%
%  Randomize the initial condition in a Hopfield network.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global hTab;
global boltzmannPopup;

if get(boltzmannPopup,'Value') > 2

	% mean field boltzmann machine

	set( hTab, 'FaceColor', [0 0.75 0] );
	set( hTab, 'UserData', 0.5 );

else

	% hopfield net or boltzmann machine

	N = length(hTab);
	for i=1:N
		if rand < 0.5

			set( hTab(i), 'FaceColor', [0 0 .5] );
			set( hTab(i), 'UserData', 0 );

		else

			set( hTab(i), 'FaceColor', [1 .5 .5] );
			set( hTab(i), 'UserData', 1 );

		end
	end
end

hopEnergy(0);

if get(boltzmannPopup,'Value') > 1

	% boltzmann machine or
	% mean field boltzmann machine

	global T;
	global Tmax;
	global nT;

	T =  Tmax;
	nT = 0;

	hopTemperature;
end

