function hopSetUnitVal( h, s )

% hopSetUnitVal.m
%
%  Set the state of (a) unit(s) in a mean field Boltzmann machine.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global unitsPopup;

if get(unitsPopup,'Value') == 2
	% 0/+1 units
else
	% -1/+1 units
end

if get(unitsPopup,'Value') == 2
	% 0/+1 units
	myR = s;
else
	% -1/+1 units
	myR = (1 + s) / 2;
end

myRnegIdx = find(myR <  0.5);
myRposIdx = find(myR >= 0.5);

myG(myRnegIdx) = 0.5 * myR(myRnegIdx);
myB(myRnegIdx) = 0.5 - myR(myRnegIdx);

myG(myRposIdx) = 1 - 0.5 * myR(myRposIdx);
myB(myRposIdx) = myR(myRposIdx) - 0.5;

myG = myG';
myB = myB';

myRGB = [myR myG myB];
for i=1:length(s)
	set( h(i), 'UserData', s(i) );
	set( h(i), 'FaceColor', myRGB(i,:) );
end

hopEnergy(0);

