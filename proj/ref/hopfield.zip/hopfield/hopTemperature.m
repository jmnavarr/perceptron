% hopTemperature.m
%
%  Display the annealing temperature in a Boltzmann machine.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global mercuryColumn;
global T;
global mThermTick;
global temperatureLabel;
global sigmoidAxes;

rectPos = get(mercuryColumn,'Position');
rectPos(4) = T * mThermTick;
set(mercuryColumn,'Position',rectPos);
set(temperatureLabel,'String',sprintf('%.3f',T));

axes(sigmoidAxes);
xpts = -10:0.1:10;
ypts = 1 ./ (1+exp(-xpts/T));
cla
plot(xpts,ypts,'r','LineWidth',2);
axis([-10 10 -0.2 1.2])

drawnow

