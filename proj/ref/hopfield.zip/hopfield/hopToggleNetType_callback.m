% hopToggleNetType_callback.m
%
%  Toggle between Hopfield net/Boltzmann machine/Mean field approx.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global boltzmannPopup;
global T;
global Tmax;
global nT;
global mThermTick;
global mercuryColumn;
global thermometer
global temperatureLabel;
global sigmoidAxes;

if get(boltzmannPopup,'Value') == 1

	% hopfield network

	set(stepButton,'String','Relax Step');
	set(relaxButton,'String','Relax');

	set(mercuryColumn,'Visible','off');
	set(thermometer,'Visible','off');
	set(temperatureLabel,'Visible','off');
	axes(sigmoidAxes);
	cla;
	set(sigmoidAxes,'Visible','off');

elseif get(boltzmannPopup,'Value') == 2

	% boltzmann machine

	set(stepButton,'String','Anneal Step');
	set(relaxButton,'String','Anneal');

	set(mercuryColumn,'Visible','on');
	set(thermometer,'Visible','on');
	set(temperatureLabel,'Visible','on');
	set(sigmoidAxes,'Visible','on');

	T = Tmax;
	nT = 0;

	hopTemperature;

else

	% mean field approx

	set(stepButton,'String','Relax Step');
	set(relaxButton,'String','Relax');

	set(mercuryColumn,'Visible','off');
	set(thermometer,'Visible','off');
	set(temperatureLabel,'Visible','off');
	set(sigmoidAxes,'Visible','on');

	T = Tmax;
	nT = 0;

	hopTemperature;
	
end

