% hopToggleUnitType_callback.m
%
%  Toggle between 0/+1 and -1/+1 unit types in a Hopfield network.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

global unitsPopup;
global offUnitsLegend;

if get(unitsPopup,'Value') == 2
	% 0/+1 units
	set(offUnitsLegend,'String','Off (0)');
else
	% -1/+1 units
	set(offUnitsLegend,'String','Off (-1)');
end

hopEnergy(0);

