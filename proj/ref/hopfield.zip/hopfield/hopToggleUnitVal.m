function hopToggleUnitVal( h )

% hopToggleUnitVal.m
%
%  Toggle the state of (a) unit(s) in a Hopfield network.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

for i=1:length(h)
	s = get( h(i), 'UserData' );

	if s > 0
		set( h(i), 'UserData', 0 );
		set( h(i), 'FaceColor', [0 0 .5] );
	else
		set( h(i), 'UserData', 1 );
		set( h(i), 'FaceColor', [1 .5 .5] );
	end
end

hopEnergy(0);

