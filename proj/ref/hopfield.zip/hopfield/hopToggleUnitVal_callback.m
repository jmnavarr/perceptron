% hopToggleUnitVal_callback.m
%
%  Toggle the state of the current unit in a Hopfield network.
%  kornel laskowski & dave touretzky (c) 2004
%  cmu 15-782 artificial neural networks

hopToggleUnitVal( gco );

