% display the energy landscape

sbits = 2 .^ (0:6);

m = zeros(128,7);

E = zeros(1,128);

unit_type = get(unitsPopup,'Value');

for i=0:127;
  b = mod(floor(i ./ sbits),2);
  if unit_type == 1
    b = 2*b - 1;
  end
  neti = b * W;
  E(i+1) = -sum(b .* neti)/2;
end

figure(2)
whitebg(gcf,[0 0 0])
plot(E)
axis([1 128 -20 15])
