% [WI,WJ] = KOHCOORDS(K,GRIDSIZE)
%	Converts vector coordinate K to grid coordinates [WI,WJ].

function [wi,wj] =  kohcoords(k,gridsize)

  wj = 1+floor((k-1)/gridsize(1));
  wi = k-(wj-1)*gridsize(1);
