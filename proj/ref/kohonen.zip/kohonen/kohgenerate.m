% Z = KOHGENERATE(D)
% Generate a training set for Kohonen feature map.
%   Options are:
%     1  square
%     2  circle
%     3  L-shape
%     4  triangle
%     5  square with cutout
%     6  two blobs
%     7  sine wave

function Z = kohgenerate(D)

  V = rand(6000,2);

  if D==1
    % square
    Z = rand(1500,2)*0.8+0.1;
  elseif D==2
    % circle
    dist = sqrt(sum(((V-0.5).^2)'));
    good = dist<0.4;
    Z=V(good(1:2000),:);
  elseif D==3 
    % L-shape
    good = V(:,1)<0.4 | V(:,2)<0.4;
    Z = V(good(1:2000),:)*0.8+0.1;
  elseif D==4
    % triangle
    bad = (V(:,1)*2 < V(:,2)) | ((1-V(:,1))*2 < V(:,2));
    good = ~bad;
    Z = V(good(1:2000),:)*0.7+0.15;
  elseif D==5
    % square with cutout
    good = abs(V(:,1)-0.5)>0.2 | abs(V(:,2)-0.5)>0.2;
    Z = V(good(1:2000),:)*0.8+0.1;
  elseif D==6
    % two blobs: a circle and a square
    dist = sqrt(sum(((V-0.5).^2)'));
    good = dist<0.5;
    V=V*0.3;
      % note: in the line below we apply good(501:1000) to V(1:end), which
      % produces a square with about as many points as the circle has
    Z=[V(good(1:500),:); V(good(501:1000),:)+0.5]+.1;
  elseif D==7
    % sine wave
    good = abs((1+sin(V(:,2)*2*pi))/2.1-V(:,1)) < 0.15;
    Z = V(good(1:2000),:)*0.9+0.05;
  else
    error('KohDataSet must be between 1 and 7')
  end
