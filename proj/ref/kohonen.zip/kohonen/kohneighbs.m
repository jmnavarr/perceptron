% NEIGHBS = KOHNEIGHBS(GRIDSIZE,NEIGHBSIZE,LRATE)
%
%	GRIDSIZE = [M,N] is the size of the grid.
%	NEIGHBSIZE is a scale factor for the neighborhood function.
%	LRATE is the learning rate.
%
%	NEIGHBS is an M x N cell array whose elements are M x N matrices
%	which define the degree of updating for each of the neighbors 
%	of that unit.

function NEIGHBS = kohneighbs(GRIDSIZE,NEIGHBSIZE,LRATE)

  M = GRIDSIZE(1); N = GRIDSIZE(2);
  mcoords = (1:M)' * ones(1,N);
  ncoords = ones(M,1) * (1:N);
  nvalues = exp(-(0:((M-1)^2+(N-1)^2))/(NEIGHBSIZE^2)) * LRATE;

  for i = 1:M
    for j = 1:N
      distsqmat = (i-mcoords).^2 + (j-ncoords).^2 + 1;
      NEIGHBS{i,j} = nvalues(distsqmat);
    end
  end
