% KOHSHOW  -- display weight vectors, training data, 
%	      and simulation parameters

    % Set up the three subwindows
  clf, whitebg(gcf,[0 0 0])
  set(gcf,'Name','Kohonen Demo','Color',[0 0 0])
  axmain = axes('Position',[0 0 0.7 1]);
  axtext = axes('Position',[0.7 0.5 0.3 0.5]);
  axneighb = axes('Position',[0.7 0 0.3 0.5]);

    % Plot the training data
  subplot(axmain)
  hold on, axis equal, axis([0 1 0 1]), axis off
  plot(Data(:,1),Data(:,2),'c.','MarkerSize',3)

    % Plot the grid of weight vectors
  M=size(W,1); N=size(W,2);
  for i = 1:M
    for j = 1:N

      % Plot a circle at the location of unit (i,j)
      plot(W(i,j,1),W(i,j,2),'or')

      % Plot line from unit (i,j) to right neighbor
      if i<M, plot(W(i+[0 1],j,1),W(i+[0 1],j,2)), end

      % Plot line from unit (i,j) to bottom neighbor
      if j<N, plot(W(i,j+[0 1],1),W(i,j+[0 1],2)), end

    end
  end

    % Show simulation parameters
  subplot(axtext)
  axis ij, axis off
  text(0.1,.1,sprintf('Iteration = %d',Iter))
  text(0.1,.2,sprintf('NeighborhoodSize = %4.3f',NeighborhoodSize))
  text(0.1,.4,sprintf('GridSize = [%d,%d]',GridSize))
  text(0.1,.5,sprintf('LearnRate = %4.3f',LearnRate))
  text(0.1,.6,sprintf('Init Neighb. Size = %3.2f',InitNeighborhoodSize))
  text(0.1,.7,sprintf('CollapseRate = %4.3f',CollapseRate))

    % Show neighborhood
  subplot(axneighb)
  hold on, axis equal, axis([0 M+1 0 N+1]), axis off
  [wi,wj] = kohcoords(1:(M*N), GridSize);
  plot(wi,wj,'w+')
  t1=text(0,N+1,' Neighbor Weight: ');
  t1e=get(t1,'Extent'); t1e=t1e(3);
  t2=text(t1e,N+1,' 0.9','Color',[1 0 0]);
  t2e=get(t2,'Extent'); t2e=t2e(3);
  text(t1e+t2e,N+1,' 0.5','Color',[1 1 0]);
  text(t1e+2*t2e,N+1,' 0.1','Color',[0 1 0]);

  mx = ceil(M/2);
  my = ceil(N/2);
  circx = cos(0:pi/20:2*pi);
  circy = sin(0:pi/20:2*pi);
  d1 = sqrt(-NeighborhoodSize^2*log(0.9));
  plot(circx*d1+mx,circy*d1+my,'r')
  d2 = sqrt(-NeighborhoodSize^2*log(0.5));
  plot(circx*d2+mx,circy*d2+my,'y')
  d3 = sqrt(-NeighborhoodSize^2*log(0.1));
  plot(circx*d3+mx,circy*d3+my,'g')

  drawnow
