if get(method_menu,'Value') ~= 1 %Not Gradient Descent,
   set(rate_slider,'BackgroundColor',[.3 .3 .3]);
   set(momentum_slider,'BackgroundColor',[.3 .3 .3]);
   set(rate_text,'BackgroundColor',[.3 .3 .3]);
   set(momentum_text,'BackgroundColor',[.3 .3 .3]);
else
   set(rate_slider,'BackgroundColor',[.7 .7 .7]);
   set(momentum_slider,'BackgroundColor',[.7 .7 .7]);
   set(rate_text,'BackgroundColor',[.7 .7 .7]);
   set(momentum_text,'BackgroundColor',[.7 .7 .7]);
end
