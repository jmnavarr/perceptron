% Demo of Gradient Descent, Line Search and Conjugate Gradient on
% a quadratic error surface.
%
% Aaron Courville, Carnegie Mellon University.
% Using Code from the bump attractor demo of David S. Touretzky
% February, 2002.

%Constants used to begin the line search routine
A = -2;
B = 0;
C = 2;

contours = exp([-5:0.5:2]); %Sets the positions of the contour lines

setup_defaults
run_flag = Inf;
