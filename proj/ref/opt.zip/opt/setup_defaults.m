%Sets the default values of the parameters

default_Momentum = 0;
default_LearnRate = 0.75; 
default_Hessian = [1 -.95; -.95 2];

Momentum = default_Momentum;
LearnRate = default_LearnRate;
Hessian = default_Hessian;

setup_display;
ErrorSurface;
