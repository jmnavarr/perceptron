clf reset
clear good_to_go
axes('Units','pixels','Position',[30 100 500 300])

makevalbox('p',3,[25 5])
makevalbox('Npts',100,[75 5])
makevalbox('Ntrain',20,[125 5])

h = uicontrol('Position',[200 10 150 30],'Style','popup', ...
    'String',{'simple sine','sum of sines','noisy sines','decaying sines'}, 'Value',1, ...
    'BackGroundColor',[1 0.8 0.4], 'FontWeight','bold',...
    'CallBack','updatefnspec(gcbo)');
updatefnspec(h)


uicontrol('Position',[400 10 100 30],'Style','popup', ...
    'String',{'FIR','IIR'}, 'Value',1, ...
    'BackGroundColor',[1 0.4 0.8], 'FontWeight','bold',...
    'CallBack','filter_flag=get(gcbo,''Value'')-1;doplot');
filter_flag = 0;

good_to_go = 1;
doplot
