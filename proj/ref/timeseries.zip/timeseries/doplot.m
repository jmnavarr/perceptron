if ~exist('good_to_go'), return, end

t = 1:Npts;

signal = feval(fobj,t);

pred = predict(signal, p, Ntrain, filter_flag);
perr = signal(Ntrain+1:end) - pred;

subplot(2,1,1);
cla
hold on
plot(t,signal,'b-o')
plot(t(Ntrain+1:end),pred,'r-*');
plot(t(Ntrain+1:end),perr,'Color',[0 0.5 0]);
subplot(2,1,2);
cla
hold on
plot(t(Ntrain+1:end),signal(Ntrain+1:end),'b-o')
plot(t(Ntrain+1:end),pred,'r-*');
plot(t(Ntrain+1:end),perr,'Color',[0 0.5 0]);
