function y = sine_fn(t)

y = sin(0.1*t);
