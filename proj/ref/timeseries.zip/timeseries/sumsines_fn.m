function y = sine_fn(t)

y = sin(0.1*t) + 3*cos(0.3*t).*sin(0.05*t) + 5*sin(0.5*t).*cos(0.01*t);
