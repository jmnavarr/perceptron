function updatefnspec(obj)

switch get(obj,'Value')
  case 1
    newfn = @sine_fn;
  case 2
    newfn = @sumsines_fn;
  case 3
    newfn = @noisysines_fn;
  case 4
    newfn = @decaysines_fn;
  otherwise
    newfn = @sin_fn;
end

assignin('base','fobj',newfn)

evalin('base','doplot')
