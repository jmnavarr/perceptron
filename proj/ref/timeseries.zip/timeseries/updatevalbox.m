function updatevalbox(obj)

val = eval(get(obj,'string'));
val = val(1);

set(obj,'Value',val,'String',num2str(val))

varname = get(obj,'UserData');
assignin('base',varname,val)

evalin('base','doplot')

